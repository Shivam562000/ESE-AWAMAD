const express = require("express");
const path = require("path");

const cors = require("cors");
const corsOptions = {
  credentials: true,
  optionSuccessStatus: 200,
};

const app = express();

app.use(cors(corsOptions));

app.use(express.static("public"));
app.use("/css", express.static(__dirname + "public/css"));
app.use("/images", express.static(__dirname + "public/images"));
app.use("/js", express.static(__dirname + "public/js"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname + "/index.html"));
});

app.post("/forms/contact", (req, res) => {
  console.log(req.body);
  res.redirect("/");
});

const PORT = 3333;
app.listen(PORT, () => console.log("Listening on 3333"));
